package Demo;

import entities.Entity;
import graphics.Screen;
import graphics.Texture;
import graphics.Window;
import physics.Gravity;

public class Demo {

	public Demo() throws Exception {

	}

	ClassLoader cl = getClass().getClassLoader();

	Texture t = new Texture("/res/1default.png", 100, 100);
	Entity e = new Entity(100, 0, t.getWidth(), t.getHeight(),1, t);
	 Texture bg = new Texture("/res/bg.png", 960, 540);

	private void render(Screen screen) {
		// screen.drawTexture(0, 0, bg);
		screen.drawTexture(e.getX(), e.getY() - e.getH(), e.getTexture());

	}

	private void loop() throws InterruptedException {
		Window window = new Window("Game", 960, 540);
		window.show();
		Screen screen = window.getScreen();
		Gravity g = new Gravity();
		int dx = (int) (1000 / 60);
		g.addEntity(e);
		while (true) {

			// screen = window.getScreen();

			screen.clear(255255255);

			this.render(screen);

			window.update();
			g.update();
			Thread.sleep(dx);

		}
	}

	public static void main(String[] args) throws Exception {

		Demo game = new Demo();
		game.loop();

	}

}